=============================================
CPUminer for GC3355 5-chip DualMiner USB ASIC
=============================================

This is the latest version of the modified CPUminer for Gridseeds 5-chip DualMiner ASIC devices compiled for Windows. This is the version that has the built-in fix for lower power consumption when minin only in Scrypt mode, so it is recommended to use this version instead of the original provided one. With this version you should be getting only about 8W of power consumption instead of about 60W when mining only Scrypt crypto currencies!

Set your setings in the miner-START.bat file and run it to start mining with lower power consumption.


Compiled for Windows and provided to you by http://www.cryptomining-blog.com

---

Donations are welcome:
BTC: 14vZ4DHDzhttzKyNAmLzpRq6VLmCGb16vX
LTC: Lav98DMvJbvMGFV8QFrhk6hxJWKMVg9fFR