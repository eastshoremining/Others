CGMiner 3.72 with GridSeed GC3355 ASIC support

GC3355-specific options can be specified via --gridseed-options or "gridseed-options" in the configuration file as a comma-separated list of sub-options:

    baud - miner baud rate (default 115200)
    freq - a choice of a list of frequencies:

250, 400, 450, 500, 550, 600, 650, 700, 706, 713, 719, 725, 731, 738, 744, 750, 756, 763, 769, 775, 781, 788, 794, 800, 813, 825, 838, 850, 863, 875, 888, 900, 913, 925, 938, 950, 963, 975, 988, 1000, 1013, 1025, 1038, 1050, 1063, 1075, 1088, 1100, 1113, 1125, 1138, 1150, 1163, 1175, 1188, 1200, 1213, 1225, 1238, 1250, 1263, 1275, 1288, 1300, 1313, 1325, 1338, 1350, 1363, 1375, 1388, 1400

    pll_r, pll_f, pll_od - fine-grained frequency tuning; see below
    chips - number of chips per device (default 5)

If pll_r/pll_f/pll_od are specified, freq is ignored, and calculated as follows:

    Fin = 25
    Fref = int(Fin / (pll_r + 1))
    Fvco = int(Fref * (pll_f + 1))
    Fout = int(Fvco / (1 << pll_od))
    freq = Fout

This version of cgminer turns off all BTC cores so that power usage is low. On a 5-chip USB miner, power usage is around 10 W. GPUs are also supported.

Also you are able to set different operating frequency for each device by giving the devices� serial number and operating frequency using the option gridseed-freq, below is an example:

--gridseed-freq 6D9426984857=988,6D9656774857=975,6D8956965251=975


The latest update includes proper support for the local hashrate reporting of the new 80-chip Gridseed G-Blade miners.


---

Original Source: https://github.com/girnyau/cgminer-gc3355

Compiled for windows by: http://cryptomining-blog.com

---

Donations are welcome:
BTC: 14vZ4DHDzhttzKyNAmLzpRq6VLmCGb16vX
LTC: Lav98DMvJbvMGFV8QFrhk6hxJWKMVg9fFR
DOGE: DM5ToRakSRQPVH4U2NA7deLNi1JZVqTtwi