
========================================
building step(Refer to cgminer original readme):


in building configration step, you just need to run:

autoreconf -fvi

CFLAGS="-O2" ./configure


As the configure.ac is changed to support the zeus ltc miner now.



=================================
execution  example:

cgminer.exe -o stratum+tcp://usa-1.liteguardian.com:3335 -u aaaa.256 -p x  --chips-count 256 --ltc-clk 200 -S //./COM4 



===================================
execution option readme:

--ltc-debug 
enable debug info output

--chips-count 6
6 chips in one COM port

   Blizzard: 6
   Cyclone: 96
   Hurricane X2: 48 (2*24)
   Hurricane X3: 64 (2*32)
   Thunder X2: 96 (4*24)
   Thunder X3: 128 (4*32)


--ltc-clk  200
clock 200M

All X6 low power miner must set the ltc-clk lower than 248 

--nocheck-golden
init with no Golden number check

--nocheck-scrypt
Don't check the miner's result. 
Must set it on openwrt 703N version, as the scrypt.c calculates wrong on MIPS platform.

--zeus-readcount
readcount (seconds*10) timeout to start a new work


===============================================
Document:

User manual:
http://zeusminer.com/user-manual-ver-1-0/

Zeus scrypt chip��s software implementation:
https://onedrive.live.com/view.aspx?resid=7B9890399DE89575!603&ithint=file%2c.docx&app=Word&authkey=!ABXOuckyMb5Cu2w

==============================================

update:
2014.07.09
Adjust Average Mhs to be WU value related

2014.06.20
Use Zeus driver instead of Icarus.
Use ncurses as default.


